
package numericlinkedlist;


class Node{
    
    int key;
    Node next;
    
    public Node(int data){
        key = data;
        next = null;
    }
}